package clinica_persistence;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import clinica_model.Veterinario;
import clinica_persistence.DatabaseConnection;

public class VeterinarioPersistence {

    // Método helper para notificar errores de forma amigable
    private static void notificarError(String accion, SQLException e) {
        String mensaje = e.getMessage();
        if (mensaje.contains("UNIQUE constraint failed")) {
            System.out.println("Error al " + accion + ": registro duplicado.");
        } else if (mensaje.contains("FOREIGN KEY constraint failed")) {
            System.out.println("Error al " + accion + ": violación de clave foránea.");
        } else if (mensaje.contains("PRIMARY KEY")) {
            System.out.println("Error al " + accion + ": conflicto con clave primaria.");
        } else {
            System.out.println("Error al " + accion + ": " + mensaje);
        }
    }

    /**
     * Inserta un nuevo Vehiculo en la base de datos junto con su ficha técnica.
     *
     * @param veterinario Objeto Veterinario con los datos a insertar. Su id se
     *                    actualizará con el id generado por la base de datos en
     *                    caso de éxito.
     * @return true si la inserción (veterinario + detalleContrato) fue exitosa,
     *         false en caso contrario.
     */
    public static boolean create(Veterinario veterinario) {
        String sqlVeterinario = "INSERT INTO Veterinario (num_licencia, nombre, apellido, fecha_contratacion) VALUES (?, ?, ?, ?)";
        String sqlContrato = "INSERT INTO detalleContrato (salario_base, horario_semanal, veterinario_licencia) VALUES (?, ?, ?)";

        Connection connection = null;
        boolean insertado = false;

        if (veterinario == null || veterinario.getNum_licencia() <= 0) {
            return false; 
        }

        try {
            connection = DatabaseConnection.getConnection();
            connection.setAutoCommit(false);

            // Inserción del veterinario
            PreparedStatement stmtVeterinario = connection.prepareStatement(sqlVeterinario);
            stmtVeterinario.setInt(1, veterinario.getNum_licencia());
            stmtVeterinario.setString(2, veterinario.getNombre());
            stmtVeterinario.setString(3, veterinario.getApellido());
            stmtVeterinario.setString(4, veterinario.getFecha_contratacion());
            insertado = stmtVeterinario.executeUpdate() > 0;
            stmtVeterinario.close();

            // Inserción del contrato
            if (insertado) {
                PreparedStatement stmtContrato = connection.prepareStatement(sqlContrato);
                stmtContrato.setDouble(1, veterinario.getSalarioBase());
                stmtContrato.setDouble(2, veterinario.getHorarioSemanal());
                stmtContrato.setInt(3, veterinario.getNum_licencia());
                insertado = stmtContrato.executeUpdate() > 0;
                stmtContrato.close();
            }

            if (insertado) {
                connection.commit();
            } else {
                connection.rollback();
            }

        } catch (SQLException e) {
            notificarError("crear veterinario", e);
            insertado = false;
            try {
                if (connection != null) {
                    connection.rollback();
                }
            } catch (SQLException e1) {
                notificarError("hacer rollback", e1);
            }
        } finally {
            try {
                if (connection != null) {
                    connection.setAutoCommit(true);
                }
            } catch (SQLException e) {
                notificarError("restaurar autoCommit", e);
            }
        }

        return insertado;
    }

    /**
     * Recupera todos los veterinarios de la base de datos, completando también la
     * información del contrato asociado a cada veterinario.
     *
     * @return Lista de veterinarios; en caso de error devuelve una lista vacía.
     */
    public static List<Veterinario> readAll() {

        List<Veterinario> veterinarios = new ArrayList<>();
        String sqlVeterinario = "SELECT num_licencia, nombre, apellido, fecha_contratacion FROM Veterinario";
        String sqlContrato = "SELECT salario_base, horario_semanal FROM detalleContrato WHERE veterinario_licencia = ?";

        Connection connection = null;

        try {
            connection = DatabaseConnection.getConnection();
            Statement stmt = connection.createStatement();
            ResultSet rsVeterinario = stmt.executeQuery(sqlVeterinario);

            while (rsVeterinario.next()) {
                Veterinario v = new Veterinario(rsVeterinario.getInt("num_licencia"), rsVeterinario.getString("nombre"),
                        rsVeterinario.getString("apellido"), rsVeterinario.getString("fecha_contratacion"), 0, 0.0,
                        0.0); // Valores temporales para el contrato
                veterinarios.add(v);
            }

            rsVeterinario.close();
            stmt.close();

            // Ahora obtenemos los detalles del contrato para cada veterinario
            PreparedStatement pstmtContrato = connection.prepareStatement(sqlContrato);
            for (int i = 0; i < veterinarios.size(); i++) {

                Veterinario v = veterinarios.get(i);
                pstmtContrato.setInt(1, v.getNum_licencia());
                ResultSet rsContrato = pstmtContrato.executeQuery();

                if (rsContrato.next()) {
                    v.setSalarioBase(rsContrato.getDouble("salario_base"));
                    v.setHorarioSemanal(rsContrato.getDouble("horario_semanal"));
                }
                rsContrato.close();

            }
            pstmtContrato.close();
        } catch (SQLException e) {
            notificarError("leer todos los veterinarios", e);
            veterinarios = new ArrayList<>(); // Devuelvo lista vacia - error
        }

        return veterinarios; // Devuelvo los registros leídos
    }

    /**
     * Recupera un Vehiculo por su identificador, incluyendo su ficha técnica.
     *
     * @param id Identificador del veterinario a recuperar.
     * @return Veterinario completo si existe;
     */
    public static Veterinario readById(int num_licencia) {
        String sqlVeterinario = "SELECT num_licencia, nombre, apellido, fecha_contratacion FROM Veterinario WHERE num_licencia = ?";
        String sqlContrato = "SELECT id, salario_base, horario_semanal FROM detalleContrato WHERE veterinario_licencia = ?";

        // Variables para almacenar los datos del veterinario y su contrato
        // Evitar null
        String nombre = "";
        String apellido = "";
        String fecha_contratacion = "";
        int contratoId = 0;
        double salarioBase = 0.0;
        double horarioSemanal = 0.0;
        Veterinario veterinario = null;

        Connection connection = null;
        try {
            connection = DatabaseConnection.getConnection();

            // Cargo los datos del veterinario
            PreparedStatement stmt = connection.prepareStatement(sqlVeterinario);
            stmt.setInt(1, num_licencia);
            ResultSet rs = stmt.executeQuery();
            boolean encontrado = false; // Disponible en la BD

            if (rs.next()) {
                nombre = rs.getString("nombre");
                apellido = rs.getString("apellido");
                fecha_contratacion = rs.getString("fecha_contratacion");
                encontrado = true;
            }

            rs.close();
            stmt.close();

            // Cargo los datos del contrato
            // Sin existe el veterinario
            if (encontrado) {

                PreparedStatement stmtContrato = connection.prepareStatement(sqlContrato);
                stmtContrato.setInt(1, num_licencia);
                ResultSet rsContrato = stmtContrato.executeQuery();

                if (rsContrato.next()) {
                    contratoId = rsContrato.getInt("id");
                    salarioBase = rsContrato.getDouble("salario_base");
                    horarioSemanal = rsContrato.getDouble("horario_semanal");
                }
                rsContrato.close();
                stmtContrato.close();

                if (encontrado) {
                    veterinario = new Veterinario(num_licencia, nombre, apellido, fecha_contratacion, contratoId,
                            salarioBase, horarioSemanal);
                }
            }
        } catch (SQLException e) {
            notificarError("leer veterinario por ID", e);
        }
        return veterinario;

    }

    /**
     * Actualiza un veterinario y su contrato. Si no existe el contrato se crea
     *
     * @param veterinario veterinario con los datos actualizados (debe incluir
     *                    licencia válido).
     * @return true si la actualización fue exitosa (y se actulizó/insertó su
     *         contrato), false en caso contrario.
     */
    public static boolean update(Veterinario veterinario) {

        // Caso de un veterinario invalido
        if (veterinario == null || veterinario.getNum_licencia() <= 0) {
            return false;
        }

        // Sentencias SQL
        String sqlVeterinarioUpdate = "UPDATE Veterinario SET nombre = ?, apellido = ?, fecha_contratacion = ? "
                + "WHERE num_licencia = ?";
        String sqlContratoUpdate = "UPDATE DetalleContrato SET salario_base = ?, horario_semanal = ? "
                + "WHERE veterinario_licencia = ?";

        // Sentencia que se usara si no existia un contrato para el veterinario | Insert
        String sqlContrtopInsert = "INSERT INTO DetalleContrato (veterinario_licencia, salario_base, horario_semanal) VALUES (?, ?, ?)";

        Connection connection = null;
        boolean actualizado = false;

        try {
            connection = DatabaseConnection.getConnection();
            connection.setAutoCommit(false);

            PreparedStatement stmt = connection.prepareStatement(sqlVeterinarioUpdate);
            stmt.setString(1, veterinario.getNombre());
            stmt.setString(2, veterinario.getApellido());
            stmt.setString(3, veterinario.getFecha_contratacion());
            stmt.setInt(4, veterinario.getNum_licencia());
            actualizado = (stmt.executeUpdate() > 0); // False - no existe elñ veterinario

            stmt.close();

            // Actualizado - existe el veterinario
            if (actualizado) {

                // Actualizo el contrato
                PreparedStatement stmtContrato = connection.prepareStatement(sqlContratoUpdate);
                stmtContrato.setDouble(1, veterinario.getSalarioBase());
                stmtContrato.setDouble(2, veterinario.getHorarioSemanal());
                stmtContrato.setInt(3, veterinario.getNum_licencia());

                boolean contratoUpdate = (stmtContrato.executeUpdate() > 0);
                stmtContrato.close();

                // Caso de que el contrato no exista
                // Se inserta
                if (!contratoUpdate) {
                    PreparedStatement stmtContratoInsert = connection.prepareStatement(sqlContrtopInsert);
                    stmtContratoInsert.setInt(1, veterinario.getNum_licencia());
                    stmtContratoInsert.setDouble(2, veterinario.getSalarioBase());
                    stmtContratoInsert.setDouble(3, veterinario.getHorarioSemanal());

                    actualizado = stmtContratoInsert.executeUpdate() > 0;
                    stmtContratoInsert.close();

                }
            }

            if (actualizado)
                connection.commit();
            else
                connection.rollback();

        } catch (SQLException e) {
            notificarError("actualizar veterinario", e);
            actualizado = false;
            try {
                if (connection != null)
                    connection.rollback();
            } catch (SQLException e1) {
                notificarError("hacer rollback", e1);
            }
        } finally {
            try {
                if (connection != null) {
                    connection.setAutoCommit(true);
                }
            } catch (SQLException e) {
                notificarError("restaurar autoCommit", e);
            }
        }

        return actualizado;
    }

    /**
     * Elimina un veterinario por su licencia; borra primero el contrato asociada y
     * después la fila del veterinario.
     *
     * @param num_licencia Licencia PK del veterinario a eliminar.
     * @return true si ambas eliminaciones se realizaron correctamente, false en
     *         caso contrario.
     */
    public static boolean delete(int num_licencia) {
        if (num_licencia <= 0) { // Licencia inválida
            return false;
        }

        String sql = "DELETE FROM Veterinario WHERE num_licencia = ?";

        Connection connection = null;
        boolean eliminado = false;

        try {
            connection = DatabaseConnection.getConnection();
            connection.setAutoCommit(false);

            // Eliminamos directamente el veterinario
            // Su contrato se elimina automaticamente:ON DELETE CASCADE
            PreparedStatement stmt = connection.prepareStatement(sql);
            stmt.setInt(1, num_licencia);
            eliminado = stmt.executeUpdate() > 0;
            stmt.close();

            if (eliminado) {
                connection.commit(); // Confirmamos cambios
            } else {
                connection.rollback(); // No existía el veterinario, revertimos
            }

        } catch (SQLException e) {
            notificarError("eliminar veterinario", e);
            eliminado = false;
            try {
                if (connection != null) {
                    connection.rollback();
                }
            } catch (SQLException e1) {
                notificarError("hacer rollback", e1);
            }
        } finally {
            try {
                if (connection != null) {
                    connection.setAutoCommit(true);
                    connection = null;
                }
            } catch (SQLException e) {
                notificarError("restaurar autoCommit", e);
            }
        }

        return eliminado;
    }

    /**
     * Elimina un Vehiculo usando el objeto Vehiculo como parámetro (delegando en
     * delete(int)).
     *
     * @param veterinario Veterinario - su licencia se usara para su eliminacion.
     * @return true si la eliminación fue exitosa, false en caso contrario.
     */
    public static boolean delete(Veterinario veterinario) {
        if (veterinario != null)
            return VeterinarioPersistence.delete(veterinario.getNum_licencia());
        else
            return false;
    }
}
