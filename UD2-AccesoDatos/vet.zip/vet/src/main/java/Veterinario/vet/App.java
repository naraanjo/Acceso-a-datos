package Veterinario.vet;

import java.util.List;
import clinica_model.Veterinario;
import clinica_persistence.VeterinarioPersistence;

public class App 
{
    public static void main(String[] args) {
    	System.out.println("Base de datos usada: " + new java.io.File("clinica.db").getAbsolutePath());

        // 🔹 Variables para pruebas rápidas
        int licenciaPrueba = 14;
        String nombreInicial = "Ana";
        String apellidoInicial = "Pérez";
        String fechaContratacion = "2025-10-25";
        double salarioInicial = 1200.0;
        double horasInicial = 40.0;

        String nombreActualizado = "Ana María";
        double salarioActualizado = 1300.0;

        // 1️⃣ Crear un veterinario nuevo
        Veterinario v1 = new Veterinario(licenciaPrueba, nombreInicial, apellidoInicial, fechaContratacion, 0, salarioInicial, horasInicial);
        boolean creado = VeterinarioPersistence.create(v1);
        System.out.println("Creación de veterinario: " + creado);

        // 2️⃣ Leer todos los veterinarios
        List<Veterinario> lista = VeterinarioPersistence.readAll();
        System.out.println("\nLista de veterinarios:");
        mostrarVeterinarios(lista);

        // 3️⃣ Leer un veterinario por ID
        Veterinario vBuscado = VeterinarioPersistence.readById(licenciaPrueba);
        if (vBuscado != null) {
            System.out.println("\nVeterinario encontrado por ID:");
            System.out.println(vBuscado.getNum_licencia() + " - " + vBuscado.getNombre() + " " + vBuscado.getApellido());
        } else {
            System.out.println("\nNo se encontró el veterinario con ID " + licenciaPrueba);
        }

        // 4️⃣ Actualizar un veterinario
        v1.setNombre(nombreActualizado);
        v1.setSalarioBase(salarioActualizado);
        boolean actualizado = VeterinarioPersistence.update(v1);
        System.out.println("\nActualización del veterinario: " + actualizado);
    }
        // 5️⃣ Verificar cambios
    /*    Veterinario vActualizado = VeterinarioPersistence.readById(licenciaPrueba);
        if (vActualizado != null) {
            System.out.println("Veterinario actualizado:");
            System.out.println(vActualizado.getNombre() + " | Salario: " + vActualizado.getSalarioBase());
        }

        // 6️⃣ Eliminar el veterinario
        boolean eliminado = VeterinarioPersistence.delete(licenciaPrueba);
        System.out.println("\nEliminación del veterinario: " + eliminado);

        // 7️⃣ Comprobar eliminación
        Veterinario vEliminado = VeterinarioPersistence.readById(licenciaPrueba);
        System.out.println("Intento de lectura después de eliminación: " + (vEliminado == null ? "No encontrado" : "Encontrado"));
    }*/

    // 🔹 Método helper para mostrar listas de veterinarios
    private static void mostrarVeterinarios(List<Veterinario> lista) {
        if (lista.isEmpty()) {
            System.out.println("No hay veterinarios registrados.");
            return;
        }
        for (Veterinario v : lista) {
            System.out.println(v.getNum_licencia() + " - " + v.getNombre() + " " + v.getApellido()
                    + " | Salario: " + v.getSalarioBase() + " | Horas: " + v.getHorarioSemanal());
        }
    }
}
