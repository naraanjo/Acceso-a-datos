import java.sql.SQLException;

private static void notificarError(String accion, SQLException e) {
    String mensaje = e.getMessage();

    if (mensaje.contains("UNIQUE constraint failed")) {
        System.out.println("Error al " + accion + ": registro duplicado.");
    } else if (mensaje.contains("FOREIGN KEY constraint failed")) {
        System.out.println("Error al " + accion + ": violación de clave foránea.");
    } else if (mensaje.contains("PRIMARY KEY")) {
        System.out.println("Error al " + accion + ": conflicto con clave primaria.");
    } else {
        System.out.println("Error al " + accion + ": " + mensaje);
    }
}
