package clinica_model;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;

/**
 * Clase Modelo Veterinario UNIFICADA. Contiene los atributos del Veterinario
 * (Tabla principal) y del DetalleContrato (Relación 1:1),
 * 
 */
public class Veterinario {

	private static final DateTimeFormatter ISO_DATE_FORMATTER = DateTimeFormatter.ofPattern("yyyy-MM-dd");

	// --- ATRIBUTOS DE LA TABLA Veterinario---
	private int num_licencia;
	private String nombre;
	private String apellido;
	private String fecha_contratacion; // String (YYYY-MM-DD) validado.

	// --- ATRIBUTOS DE LA TABLA DetalleContrato ) ---

	// Se mantiene 'id' aunque se asuma que es FK de Veterinario. Se usa para mapeo
	// DB.
	private int contratoId;
	private double salarioBase;
	private double horarioSemanal; // Horas trabajadas a la semana

	// Constructor Vacío (Defensivo)
	public Veterinario() {
		this.num_licencia = 0;
		this.nombre = "";
		this.apellido = "";
		this.fecha_contratacion = "";

		// Inicialización de Contrato (1:1)
		this.contratoId = 0;
		this.salarioBase = 0.0;
		this.horarioSemanal = 0.0;

		// Inicialización de Certificaciones (1:N)
	}

	// Constructor Completo (Solo atributos de 'Veterinario')
	// El constructor completo de DetalleContrato no se usa aquí para simplificar.
	public Veterinario(int num_licencia, String nombre, String apellido, String fecha_contratacion, int contratoId,
			double salarioBase, double horarioSemanal) {

		// Validación de atributos de Veterinario
		this.num_licencia = (num_licencia > 0) ? num_licencia : 0;
		this.nombre = (nombre != null && !nombre.trim().isEmpty()) ? nombre.trim() : "";
		this.apellido = (apellido != null && !apellido.trim().isEmpty()) ? apellido.trim() : "";
		setFecha_contratacion(fecha_contratacion);

		// Validación de atributos de DetalleContrato
		this.contratoId = (contratoId >= 0) ? contratoId : 0;
		this.salarioBase = (salarioBase >= 0.0) ? salarioBase : 0.0;
		this.horarioSemanal = (horarioSemanal > 0 && horarioSemanal <= 60) ? horarioSemanal : 0;

	}

	// Getters y Setters

	public int getNum_licencia() {
		return num_licencia;
	}

	public void setNum_licencia(int num_licencia) {
		this.num_licencia = (num_licencia > 0) ? num_licencia : 0;
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = (nombre != null && !nombre.trim().isEmpty()) ? nombre.trim() : "";
	}

	public String getApellido() {
		return apellido;
	}

	public void setApellido(String apellido) {
		this.apellido = (apellido != null && !apellido.trim().isEmpty()) ? apellido.trim() : "";
	}

	public String getFecha_contratacion() {
		return fecha_contratacion;
	}

	public void setFecha_contratacion(String fecha_contratacion) {
		// Aplicamos la validación rigurosa: si es válida la asigna, si no, asigna "".
		this.fecha_contratacion = validateAndFormatDate(fecha_contratacion);
	}

	/**
	 * Valida si la cadena de fecha cumple con el formato YYYY-MM-DD y es
	 * lógicamente válida. Si es válida, devuelve la cadena formateada; si no lo es,
	 * devuelve cadena vacía "".
	 */
	private String validateAndFormatDate(String fecha_contratacion_str) {
		if (fecha_contratacion_str == null || fecha_contratacion_str.trim().isEmpty()) {
			return ""; // Evita null, devuelve cadena vacía.
		}

		try {
			// Usa LocalDate para validar formato (YYYY-MM-DD) y validez lógica (ej: no 30
			// de febrero)
			LocalDate date = LocalDate.parse(fecha_contratacion_str.trim(), ISO_DATE_FORMATTER);
			return date.format(ISO_DATE_FORMATTER);

		} catch (DateTimeParseException e) {
			// Si falla la validación, devolvemos cadena vacía
			return "";
		}
	}

	public int getContratoId() {
		return contratoId;
	}

	public void setContratoId(int contratoId) {
		this.contratoId = (contratoId >= 0) ? contratoId : 0;
	}

	public double getSalarioBase() {
		return salarioBase;
	}

	public void setSalarioBase(double salarioBase) {
		this.salarioBase = (salarioBase >= 0.0) ? salarioBase : 0.0;
	}

	public double getHorarioSemanal() {
		return horarioSemanal;
	}

	public void setHorarioSemanal(double horarioSemanal) {
		// Unicamente es valido entre 1 y 60 horas de trabajo semanales en mi Bd
		this.horarioSemanal = (horarioSemanal > 0 && horarioSemanal <= 60) ? horarioSemanal : 0;
	}

}
